<div class="lo_fr_a">
	<?php 
		if ($user == "") {
			echo '<p>
				<a style= "text-decoration: none; color: #DDD;" href="login.php">Log in?</a>
			</p>
			';
		}else {
			echo '<p>
				<a style= "text-decoration: none; color: #DDD;" href="logout.php">Log out?</a>
			</p>';
		}
	?>
	
	<p class="lo_fr_a_">Use Mozila or Default Internet Browser for Best Performance.</br></br>Daowat &copy 2016</p>
</div>