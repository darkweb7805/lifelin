<?php include ( "./inc/connect.inc.php" ); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Daowat</title>
	<link rel="icon" href="./img/title.png" type="image/x-icon">
	<meta charset="uft-8">
	<link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
<body>

<div>
	<div><?php include ( "./inc/header.inc.php" ); ?></div>
	<div class="succReg">
		<p>Assalamu Alaikum Brother</p><br><br>
		<h1>Nothing found</h1>
	</div>
	<div><?php include ( "./inc/footer.inc.php"); ?></div>
</div>

</body>
</html>