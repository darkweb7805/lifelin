# DAOWAT - Social Network

## Website Live Preview
Go to this link: <br>
https://daowatdemo.000webhostapp.com

## Summary
I get curious after using facebook how this works. Then I start learning web programming. Within 4 month develop this website and host it with the domain name DAOWAT. Sorry to say, now this project is not live :(

## Platform Used
### Front-End
  (i) HTML5 <br>
  (ii) CSS3 <br>
  (iii) JavaScript <br>
  (iv) Ajax <br>

### Back-End
  (i) PHP <br>
  (ii) MySQL <br>

## Key Features
### Public User
(i) Create User Account <br>
(ii) View Public Post <br>

### Signin User
#### Post
(i) Text <br>
(ii) Image <br>
(iii) Like, Comment & Share <br>
(iv) Public, Firnds & Only Me Option <br>
(v) Edit Post (Post owner) <br>
#### About
(i) Work & Education  <br>
(ii) Contact Information <br>
(iii) About Yourself <br>
#### Friends
Can sent friend request and follow if want. Friends option include:  <br>
(i) Friends List <br>
(ii) Follower List <br>
(iii) Following List <br>
#### Notification
(i) Like Your Post <br>
(ii) Comment On Your Post <br>
#### Settings
(i) Update Name, Username & Gender <br>
(ii) Update Email & Password <br>

### Admin
Admin has all rights whatever he want. <br>

## Conclusion
There are also many more feature which are not in the list.
