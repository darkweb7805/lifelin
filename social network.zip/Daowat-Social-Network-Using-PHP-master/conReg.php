<?php include ( "./inc/connect.inc.php" ); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Confirm Registration</title>
	<link rel="icon" href="./img/title.png" type="image/x-icon">
	<meta charset="uft-8">
	<link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
<body>

<div>
	<div><?php include ( "./inc/login.inc.php" ); ?></div>
	<div class="succReg">
		<p>Assalamu Alaikum Brother</p><br><br>
		<h1>Registration successfull. Nowadays Daowat.com is free for well known brother.</h1>
		<h1>Within 12 hours confirmation email send to you insha-allah .</h1>
	</div>
	<div><?php include ( "./inc/footer.inc.php"); ?></div>
</div>

</body>
</html>
