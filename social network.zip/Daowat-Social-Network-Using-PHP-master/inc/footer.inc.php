			<div class="footer">
				<div class="f_menu">
					<a href="daowat_about.php" class="f_menu2" >|  About  |</a>
					<a href="#" class="f_menu2" >|  Help  |</a>
					<a href="#" class="f_menu2" >|  Invite|  </a>
					<a href="#" class="f_menu2" >|  FAQ  |</a>
					<a href="#" class="f_menu2" >|  Privacy  |</a>
					<a href="#" class="f_menu2" >|  Developers  |</a>
					<a style="color:#088A08; text-decoration: none">| Mohsin E Nur production &copy; 2016  |</a>
				</div>
			</div>
		</div>
	</body>
</html>