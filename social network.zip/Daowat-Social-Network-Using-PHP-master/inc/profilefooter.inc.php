<div style="text-align: center; padding: 10px 0 0 0px;">
		<a href="daowat_about.php" style="text-decoration: none; color: #7C7979;" >  About  -</a>
		<a href="#" style="text-decoration: none; color: #7C7979;" >Help  -</a>
		<a href="#" style="text-decoration: none; color: #7C7979;" >Invite  -</a>
		<a href="#" style="text-decoration: none; color: #7C7979;" >FAQ  -</a>
		<a href="https://www.youtube.com/mohsingram" style="text-decoration: none; color: #7C7979;" >Youtube  -</a>
		<a href="https://www.facebook.com/mohsingram/" style="text-decoration: none; color: #7C7979;" >Facebook</a>
	<p href="https://www.facebook.com/mohsingram/" style="text-align: center; padding: 10px 0px;">Mohsin Gram &copy; 2016 | Daowat</p>
</div>
